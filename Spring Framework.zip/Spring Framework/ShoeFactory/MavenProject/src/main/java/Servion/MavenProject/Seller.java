package Servion.MavenProject;

public interface Seller {

	public Shoe SellShoe(Customer customer);
	
	
}
