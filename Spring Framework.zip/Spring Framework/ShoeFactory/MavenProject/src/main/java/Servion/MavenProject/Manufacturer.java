package Servion.MavenProject;

public interface Manufacturer {

	
	public abstract Shoe makeshoe();
	
}
