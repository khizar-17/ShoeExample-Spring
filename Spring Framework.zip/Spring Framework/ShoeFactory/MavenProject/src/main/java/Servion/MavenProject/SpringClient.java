package Servion.MavenProject;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class SpringClient
{
	public static void main(String[] args) 
	{	
		ConfigurableApplicationContext ctx=
				new FileSystemXmlApplicationContext("config.xml");
		ShoeShop shop=(ShoeShop) ctx.getBean("shop",ShoeShop.class);
		Customer customer=new Customer();
		customer.setName("raja");
		
		System.out.println(shop.SellShoe(customer));
	}

}
