package Servion.MavenProject;

public class LSF extends ShoeFactory{
	@Override
	public Shoe makeshoe() {
		// TODO Auto-generated method stub
		return new SportsShoe();
	}

}
