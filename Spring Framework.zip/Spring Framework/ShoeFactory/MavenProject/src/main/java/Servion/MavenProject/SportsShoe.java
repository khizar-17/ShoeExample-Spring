package Servion.MavenProject;

public class SportsShoe extends Shoe {
	
}
