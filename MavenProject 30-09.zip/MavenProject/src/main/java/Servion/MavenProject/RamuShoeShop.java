package Servion.MavenProject;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.logging.Logger;

public class RamuShoeShop extends ShoeShop {
	
	//Log4j
	private static final String CLASS_NAME=RamuShoeShop.class.getName();
	private static Logger logger=Logger.getLogger(CLASS_NAME);

/*	public Shoe SellShoe(String customer)  {
	
		Properties prop=new Properties();
		try{
		prop.load(new FileInputStream("config.properties"));
		}catch(Exception e)
		{
			System.out.println("error"+e);
		}
		
		try{
		ShoeFactory factory=(ShoeFactory) Class.forName(prop.getProperty(customer)).newInstance();
		Shoe s=factory.makeshoe();
		return s;
		}catch(Exception e)
		{
			return null;
		}
			}*/
	public Shoe SellShoe(Customer customer) {
		
		//Log4j in method
		String methodName="SellShoe";
		logger.entering(CLASS_NAME,methodName);
		logger.info("SellShoe Called");
		logger.exiting(CLASS_NAME, methodName);
		
		System.out.println(getFactory().toString());
		
		// TODO Auto-generated method stub
		return getFactory().makeshoe();
	}

	



	
}
