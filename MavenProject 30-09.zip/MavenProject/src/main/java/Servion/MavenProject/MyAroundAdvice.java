package Servion.MavenProject;

import java.util.Vector;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class MyAroundAdvice implements MethodInterceptor {
	
	Vector<Customer> v=new Vector<Customer>();
	
	public Object invoke(MethodInvocation arg0) throws Throwable {
		
		Customer customer=(Customer)arg0.getArguments()[0];
		if(v.contains(customer))
		{
			//System.out.println("one shoe....");
			throw new OneShoePerCustomer("One shoe per customer..:");
		}
		else 
		{
			v.add(customer);	
		}
	Shoe shoe=(Shoe)arg0.proceed();
	return shoe;
	}

}
