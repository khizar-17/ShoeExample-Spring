package Servion.MavenProject;

public abstract class ShoeFactory  implements Manufacturer  {

	public abstract Shoe makeshoe();
	
}
