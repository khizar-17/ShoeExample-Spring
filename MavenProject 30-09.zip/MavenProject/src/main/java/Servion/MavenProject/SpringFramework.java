package Servion.MavenProject;

import java.io.FileReader;
import java.util.Properties;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class SpringFramework 
{
public static ShoeShop getShop()
{
	try
	{
		Properties prop=new Properties();
		prop.load(new FileReader("config.properties"));
		String shopclass=prop.getProperty("shop");
		String factoryclass=prop.getProperty("factory");
		//System.out.println(factoryclass);
		ShoeFactory factory=(ShoeFactory) Class.forName(factoryclass).newInstance();
		ShoeShop seller=(ShoeShop) Class.forName(shopclass).newInstance();
		
		
		seller.setFactory(factory);
		return seller;
		
	}catch(Exception e)
	{}
	return null;	
	
	}
}	
