package Servion.MavenProject;

public abstract class Shoe {

	
}
