package Servion.MavenProject;

import java.lang.reflect.Method;
import java.util.logging.Logger;

import org.springframework.aop.MethodBeforeAdvice;

public class LoggerAdvise implements MethodBeforeAdvice

{
	private static final String CLASS_NAME=LoggerAdvise.class.getName();
	private static Logger logger=Logger.getLogger(CLASS_NAME);
	
	

	public void before(Method method, Object[] param, Object bean) throws Throwable 
	{
		
		logger.entering(method.getDeclaringClass().getName(),method.getName());
		logger.info("Logger Invoke At "+method.getClass().getName()+" "+method.getName());
		Customer customer=(Customer)param[0];
		
		logger.exiting("Logger Class Exit "+customer.getName(),method.getName());
	
	}

}
