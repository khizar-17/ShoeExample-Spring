package Servion.MavenProject;

public class BSF extends ShoeFactory{

	
	
	

	
	
	public Shoe makeshoe() {
		// TODO Auto-generated method stub
		return new LeatherShoe();
	}
	
}
