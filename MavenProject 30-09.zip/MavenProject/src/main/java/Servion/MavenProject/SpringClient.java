package Servion.MavenProject;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class SpringClient
{
	public static void main(String[] args) 
	{
		try
		{
		ConfigurableApplicationContext ctx=
				new FileSystemXmlApplicationContext("config.xml");
		Seller s=(Seller)ctx.getBean("advisedshop",Seller.class);
		Customer customer=new Customer();
		customer.setName("raja");
		
		System.out.println(s.SellShoe(customer));
		s.SellShoe(customer);
		}catch(Exception e){}
		}
	}
		


