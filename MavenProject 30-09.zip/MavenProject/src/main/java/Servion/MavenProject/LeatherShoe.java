package Servion.MavenProject;

public class LeatherShoe extends Shoe{

}
