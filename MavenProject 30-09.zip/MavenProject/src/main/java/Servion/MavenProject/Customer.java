package Servion.MavenProject;

import java.util.logging.Logger;

public class Customer {
	
	private static final String CLASS_NAME=Customer.class.getName();
	private static Logger logger=Logger.getLogger(CLASS_NAME);
	
	

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) 
	{
		String methodName="SetName";
		logger.entering(CLASS_NAME,methodName);
		logger.info("SetName Called");
		logger.exiting(CLASS_NAME, methodName);
		
		
		
		this.name = name;
		
	}
	
//	public static void main(String[] args) {
		
//		ShoeShop shop=new RamuShoeShop();

//		System.out.println(shop.SellShoe("leha"));
		
//	}
}
